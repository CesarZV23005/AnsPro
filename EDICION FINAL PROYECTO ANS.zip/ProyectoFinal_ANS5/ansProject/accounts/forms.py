from django import forms
from django.contrib.auth.models import User
from .models import Perfil

class RegistroForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ['username', 'password']

    def clean_username(self):
        username = self.cleaned_data.get('username')
        if User.objects.filter(username=username).exists():
            raise forms.ValidationError("Este nombre de usuario ya está en uso.")
        return username

class PerfilForm(forms.ModelForm):
    class Meta:
        model = Perfil
        fields = ['nombre_completo', 'correo', 'fotografia', 'carrera', 'carnet', 'ciclo']

    def clean_correo(self):
        correo = self.cleaned_data.get('correo')
        if Perfil.objects.filter(correo=correo).exists():
            raise forms.ValidationError("Este correo ya está registrado.")
        return correo

    def clean_carnet(self):
        carnet = self.cleaned_data.get('carnet')
        if Perfil.objects.filter(carnet=carnet).exists():
            raise forms.ValidationError("Este carnet ya está registrado.")
        return carnet
