from django.contrib import admin
from django.urls import path, include
from . import views  # Importa las funciones de vista desde views.py

app_name = 'accounts'  # Define un espacio de nombres para las URLs de la app 'accounts'

# Lista de rutas específicas para login, logout, registro e invitado
urlpatterns = [
    path('login/', views.login_view, name='login'),           # URL: /accounts/login/
    path('logout/', views.logout_view, name='logout'),         # URL: /accounts/logout/
    path('register/', views.register_view, name='register'),   # URL: /accounts/register/
    path('guest/', views.guest_login_view, name='guest_login'), # URL: /accounts/guest/
    path('editar-perfil/', views.editar_perfil_view, name='editar_perfil'),
    ]
