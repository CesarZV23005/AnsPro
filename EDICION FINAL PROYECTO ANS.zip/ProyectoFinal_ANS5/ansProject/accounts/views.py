from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib import messages
from .forms import RegistroForm, PerfilForm
from .models import Perfil
from django.contrib.auth.decorators import login_required


# Vista para iniciar sesión como invitado (sin contraseña)
def guest_login_view(request):
    # Obtiene o crea un usuario con nombre "invitado"
    guest_user, created = User.objects.get_or_create(username='invitado')
    
    # Le asigna una contraseña inutilizable (no se puede usar para login normal)
    guest_user.set_unusable_password()
    guest_user.save()
    
    # Inicia sesión automáticamente con el usuario invitado
    login(request, guest_user)

    # Guarda en la sesión que el usuario es invitado
    request.session['invitado'] = True

    # Redirige a la vista principal de la calculadora
    return redirect('calculadora:inicio')


# Vista para iniciar sesión con nombre de usuario y contraseña
def login_view(request):
    if request.method == 'POST':
        # Captura los datos enviados desde el formulario
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Verifica si el usuario existe y la contraseña es correcta
        user = authenticate(request, username=username, password=password)

        if user is not None:
            # Si la autenticación es válida, inicia sesión
            login(request, user)

            # Guarda el nombre de usuario en la sesión
            request.session['nombre'] = user.username

            # Marca que NO es invitado
            request.session['invitado'] = False 

            # Redirige al menú principal de la calculadora
            return redirect('calculadora:inicio')
        else:
            # Si las credenciales son incorrectas, recarga el login con un error
            return render(request, 'accounts/login.html', {'error': 'Credenciales incorrectas'})

    # Si no es POST, muestra simplemente el formulario de login
    return render(request, 'accounts/login.html')


# Vista para cerrar sesión del usuario actual
def logout_view(request):
    logout(request)                # Cierra la sesión del usuario autenticado
    request.session.flush()       # Limpia todos los datos de sesión
    return redirect('home')       # Redirige al home


def register_view(request):
    if request.method == "POST":
        user_form = RegistroForm(request.POST)
        perfil_form = PerfilForm(request.POST, request.FILES)

        if user_form.is_valid() and perfil_form.is_valid():
            user = user_form.save(commit=False)
            user.set_password(user_form.cleaned_data['password'])
            user.save()

            perfil = perfil_form.save(commit=False)
            perfil.user = user
            perfil.save()

            messages.success(request, "Usuario creado correctamente.")
            return redirect('accounts:login')
    else:
        user_form = RegistroForm()
        perfil_form = PerfilForm()

    return render(request, 'accounts/register.html', {
        'user_form': user_form,
        'perfil_form': perfil_form
    })



@login_required
def editar_perfil_view(request):
    perfil = Perfil.objects.get(user=request.user)
    
    if request.method == 'POST':
        perfil.nombre_completo = request.POST.get('nombre_completo')
        perfil.correo = request.POST.get('correo')
        perfil.carrera = request.POST.get('carrera')
        perfil.carnet = request.POST.get('carnet')
        perfil.ciclo = request.POST.get('ciclo')
        
        if request.FILES.get('fotografia'):
            perfil.fotografia = request.FILES.get('fotografia')
        
        perfil.save()
        messages.success(request, "Perfil actualizado correctamente.")
        return redirect('calculadora:inicio')

    return render(request, 'accounts/editar_perfil.html', {'perfil': perfil})
