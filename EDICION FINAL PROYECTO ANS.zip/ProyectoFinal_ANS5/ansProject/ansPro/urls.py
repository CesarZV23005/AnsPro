from django.contrib import admin
from django.urls import path, include
from ansPro.views import home, entrar_como_invitado  # Importa las vistas personalizadas del proyecto
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),  # Ruta para acceder al panel de administración de Django
    path('calculadora/', include('calculadora.urls')),  # Incluye las rutas de la app calculadora
    path('accounts/', include('accounts.urls')),  # Incluye las rutas de la app de autenticación (accounts)
    path('', home, name='home'),  # Ruta raíz del sitio (home)
    path('invitado/', entrar_como_invitado, name='invitado'),  # Ruta para acceder como invitado
]


urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
