from django.shortcuts import render, redirect  # Funciones para renderizar HTML y redirigir URLs

# Vista de la página principal (home)
def home(request):
    request.session.flush()  # Elimina todos los datos de sesión actuales (como cerrar sesión)
    return render(request, 'home.html')  # Muestra la plantilla home.html

# Vista para entrar como invitado
def entrar_como_invitado(request):
    request.session['invitado'] = True         # Marca la sesión como modo invitado
    request.session['nombre'] = 'Invitado'     # Asigna el nombre "Invitado" a la sesión
    return redirect('calculadora:inicio')      # Redirige al menú de la calculadora
