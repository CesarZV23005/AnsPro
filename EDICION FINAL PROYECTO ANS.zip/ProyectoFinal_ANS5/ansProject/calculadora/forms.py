from django import forms
import re

class PuntosForm(forms.Form):
    puntos = forms.CharField(
        label='Ingrese los puntos (x,y) separados por comas',
        widget=forms.Textarea(attrs={'rows': 4, 'class': 'form-control'}),
        help_text="Ejemplo: (1,2), (2,3), (3,5)"
    )
    x_eval = forms.FloatField(
        label='Ingrese un valor de x a interpolar (opcional)',
        required=False,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'step': 'any'})
    )

    def clean_puntos(self):
        puntos_raw = self.cleaned_data['puntos'].strip()

        # Validar formato correcto de puntos con expresión regular
        patron = r'^\s*(\(\s*-?\d+(\.\d+)?\s*,\s*-?\d+(\.\d+)?\s*\)\s*,?\s*)+$'
        if not re.fullmatch(patron, puntos_raw):
            raise forms.ValidationError("El formato de los puntos es incorrecto. Usa solo valores como: (1,2), (3,4)")

        # Extraer valores y validar duplicados o exceso de puntos
        matches = re.findall(r'\(\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*\)', puntos_raw)
        if len(matches) > 10:
            raise forms.ValidationError("Máximo 10 puntos permitidos.")

        x_vals = [float(x) for x, _ in matches]
        if len(set(x_vals)) != len(x_vals):
            raise forms.ValidationError("Hay valores de x repetidos. No se permiten duplicados.")

        return puntos_raw


class RichardsonForm(forms.Form):
    h1 = forms.FloatField(
        label="h₁", min_value=0.000001,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'step': 'any'})
    )
    h2 = forms.FloatField(
        label="h₂", min_value=0.000001,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'step': 'any'})
    )
    A_h1 = forms.FloatField(
        label="A(h₁)",
        widget=forms.NumberInput(attrs={'class': 'form-control', 'step': 'any'})
    )
    A_h2 = forms.FloatField(
        label="A(h₂)",
        widget=forms.NumberInput(attrs={'class': 'form-control', 'step': 'any'})
    )
    n = forms.IntegerField(
        label="Orden n", min_value=1,
        widget=forms.NumberInput(attrs={'class': 'form-control'})
    )

    def clean(self):
        cleaned_data = super().clean()
        h1 = cleaned_data.get("h1")
        h2 = cleaned_data.get("h2")

        if h1 and h2 and h1 == h2:
            raise forms.ValidationError("h₁ y h₂ no pueden ser iguales para realizar la extrapolación.")
