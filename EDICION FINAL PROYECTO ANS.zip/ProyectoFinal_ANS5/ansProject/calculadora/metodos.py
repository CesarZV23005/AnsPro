from sympy import symbols, simplify

# Variable simbólica para uso en interpolación
x = symbols('x')

# =======================================
# MÉTODO DE INTERPOLACIÓN DE LAGRANGE
# =======================================
def polinomio_lagrange(x_vals, y_vals):
    """
    Interpolación de Lagrange:
    Recibe listas de x_vals e y_vals.
    Devuelve:
        - polinomio simbólico simplificado
        - pasos explicativos en formato LaTeX
    """
    n = len(x_vals)
    pasos = []
    polinomio = 0

    for i in range(n):
        xi, yi = x_vals[i], y_vals[i]
        numerador = 1
        denominador = 1

        for j in range(n):
            if i != j:
                xj = x_vals[j]
                numerador *= (x - xj)
                denominador *= (xi - xj)

        li = numerador / denominador
        polinomio += yi * li
        pasos.append(
            rf"L_{{{i}}}(x) = \frac{{{numerador}}}{{{denominador}}}, "
            rf"\quad y_{{{i}}} \cdot L_{{{i}}}(x) = {yi} \cdot \left(L_{{{i}}}(x)\right)"
        )

    return simplify(polinomio), pasos


# =======================================
# MÉTODO DE EXTRAPOLACIÓN DE RICHARDSON
# =======================================
def richardson_extrapolation(h1, h2, A_h1, A_h2, n):
    """
    Extrapolación de Richardson (fórmula con factor fijo 2):
    R = (2^n * A(h2) - A(h1)) / (2^n - 1)

    Parámetros:
        - h1, h2: pasos
        - A_h1, A_h2: aproximaciones
        - n: orden del método

    Devuelve:
        - R: resultado de extrapolación
        - pasos: detalles del cálculo en LaTeX
    """
    try:
        factor = 2 ** n
        numerador = factor * A_h2 - A_h1
        denominador = factor - 1
        R = numerador / denominador

        pasos = [
            rf"Se aplica la fórmula: R = \frac{{2^n \cdot A(h_2) - A(h_1)}}{{2^n - 1}}",
            rf"R = \frac{{2^{{{n}}} \cdot {A_h2} - {A_h1}}}{{2^{{{n}}} - 1}}",
            rf"R = \frac{{{numerador}}}{{{denominador}}} = {R}"
        ]
        return R, pasos
    except Exception as e:
        return None, [f"Error en extrapolación de Richardson: {e}"]
