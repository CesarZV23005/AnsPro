from django.urls import path
from . import views

app_name = 'calculadora'

urlpatterns = [
    path('', views.inicio_view, name='inicio'),
    path('lagrange/', views.lagrange_view, name='lagrange'),
    path('richardson/', views.richardson_view, name='richardson'),
    path('historial/', views.historial_view, name='historial'),
    path('historial/<int:id>/', views.ver_historial, name='ver_historial'),
    path('rehacer/<int:historial_id>/', views.rehacer_view, name='rehacer'),
    path('documentacion/', views.documentacion_view, name='documentacion'),
    path('creditos/', views.creditos_view, name='creditos'),  # 👈 NUEVA RUTA
]
