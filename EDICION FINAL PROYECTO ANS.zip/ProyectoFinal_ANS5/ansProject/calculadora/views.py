from django.shortcuts import render, redirect, get_object_or_404
from .forms import PuntosForm
from .metodos import polinomio_lagrange, richardson_extrapolation
from .models import Historial
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from django.urls import reverse
from sympy import lambdify, symbols
import numpy as np
import re, io, base64
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

x = symbols('x')

@login_required
def historial_view(request):
    registros = Historial.objects.filter(usuario=request.user).order_by('-fecha')
    return render(request, 'calculadora/historial.html', {'registros': registros})

def inicio_view(request):
    if request.method == 'POST':
        metodo = request.POST.get('metodo')
        if metodo == 'lagrange':
            return redirect('calculadora:lagrange')
        elif metodo == 'richardson':
            return redirect('calculadora:richardson')
    return render(request, 'calculadora/inicio.html')

def lagrange_view(request):
    resultado = pasos = polinomio_final = valor_interpolado = grafico = None
    puntos_str = ""
    x_eval = None

    es_invitado = (
        request.session.get('invitado') is True or
        (request.user.is_authenticated and request.user.username == 'invitado')
    )
    mostrar_pasos = request.user.is_authenticated and not es_invitado
    nombre = request.user.username if request.user.is_authenticated else "Invitado"

    rehacer_id = request.GET.get('rehacer')
    if rehacer_id:
        historial = get_object_or_404(Historial, id=rehacer_id, usuario=request.user)
        if historial.metodo == "Lagrange":
            puntos_str = historial.entrada.split(", x")[0].replace("Puntos: ", "").strip()
            x_eval = historial.entrada.split("x = ")[1].strip()
            form = PuntosForm(initial={"puntos": puntos_str})
        else:
            form = PuntosForm()
    else:
        form = PuntosForm()

    if request.method == 'POST':
        form = PuntosForm(request.POST)
        if form.is_valid():
            puntos_str = form.cleaned_data['puntos']
            x_eval_input = form.cleaned_data.get('x_eval')

            try:
                matches = re.findall(r'\(([^)]+)\)', puntos_str)
                puntos_list = []
                for m in matches:
                    x_val, y_val = map(float, m.split(','))
                    puntos_list.append((x_val, y_val))

                x_vals = [p[0] for p in puntos_list]
                y_vals = [p[1] for p in puntos_list]

                polinomio_final, pasos = polinomio_lagrange(x_vals, y_vals)

                if x_eval_input is not None:
                    x_eval = float(x_eval_input)
                    valor_interpolado = eval(str(polinomio_final), {"x": x_eval})

                if mostrar_pasos:
                    entrada = f"Puntos: {puntos_list}, x = {x_eval}"
                    salida = f"f({x_eval}) = {valor_interpolado}"
                    Historial.objects.create(
                        usuario=request.user,
                        metodo='Lagrange',
                        entrada=entrada,
                        resultado=salida,
                        fecha=timezone.now()
                    )

                    fx = lambdify(x, polinomio_final, modules=['numpy'])
                    x_plot = np.linspace(min(x_vals) - 1, max(x_vals) + 1, 400)
                    y_plot = fx(x_plot)

                    plt.figure()
                    plt.plot(x_plot, y_plot, label='Polinomio')
                    plt.scatter(x_vals, y_vals, color='red', label='Puntos')
                    plt.title('Polinomio de Lagrange')
                    plt.xlabel('x')
                    plt.ylabel('f(x)')
                    plt.legend()
                    buffer = io.BytesIO()
                    plt.savefig(buffer, format='png')
                    buffer.seek(0)
                    grafico = base64.b64encode(buffer.getvalue()).decode()
                    buffer.close()
                    plt.close()
            except Exception as e:
                form.add_error('puntos', 'Error al procesar los puntos. Usa el formato (1,2), (3,4), ...')

    return render(request, 'calculadora/lagrange.html', {
        'form': form,
        'mostrar_pasos': mostrar_pasos,
        'nombre': nombre,
        'pasos': pasos,
        'polinomio_final': polinomio_final,
        'puntos': puntos_str,
        'x_eval': x_eval,
        'valor_interpolado': valor_interpolado,
        'grafico': grafico,
    })

def richardson_view(request):
    resultado = None
    pasos = []
    grafico = None
    rehacer_datos = {}

    es_invitado = (
        request.session.get('invitado') is True or
        (request.user.is_authenticated and request.user.username == 'invitado')
    )
    mostrar_pasos = request.user.is_authenticated and not es_invitado
    nombre = request.user.username if request.user.is_authenticated else "Invitado"

    rehacer_id = request.GET.get('rehacer')
    if rehacer_id:
        historial = get_object_or_404(Historial, id=rehacer_id, usuario=request.user)
        if historial.metodo == "Richardson":
            entrada = historial.entrada
            valores = {}
            for parte in entrada.split(","):
                if "=" in parte:
                    k, v = parte.strip().split("=")
                    valores[k.strip()] = v.strip()
            rehacer_datos = {
                'h1': valores.get('h1'),
                'h2': valores.get('h2'),
                'A_h1': valores.get('A(h1)'),
                'A_h2': valores.get('A(h2)'),
                'n': valores.get('n'),
            }

    if request.method == 'POST':
        try:
            h1 = float(request.POST.get('h1'))
            h2 = float(request.POST.get('h2'))
            A_h1 = float(request.POST.get('A_h1'))
            A_h2 = float(request.POST.get('A_h2'))
            n = int(request.POST.get('n'))

            if h1 <= 0 or h2 <= 0:
                raise ValueError("Los valores de h deben ser positivos.")
            if h1 == h2:
                raise ValueError("h1 y h2 deben ser distintos.")
            if n <= 0:
                raise ValueError("n debe ser mayor que 0.")

            resultado, pasos = richardson_extrapolation(h1, h2, A_h1, A_h2, n)

            if mostrar_pasos:
                entrada = f"h1={h1}, h2={h2}, A(h1)={A_h1}, A(h2)={A_h2}, n={n}"
                salida = str(resultado)
                Historial.objects.create(
                    usuario=request.user,
                    metodo='Richardson',
                    entrada=entrada,
                    resultado=salida,
                    fecha=timezone.now()
                )

                h_vals = [h1, h2]
                A_vals = [A_h1, A_h2]
                plt.figure()
                plt.plot(h_vals, A_vals, 'bo--', label='Aproximaciones')
                plt.axhline(y=resultado, color='red', linestyle='--', label='Richardson R')
                plt.title('Extrapolación de Richardson')
                plt.xlabel('h')
                plt.ylabel('A(h)')
                plt.legend()
                buffer = io.BytesIO()
                plt.savefig(buffer, format='png')
                buffer.seek(0)
                grafico = base64.b64encode(buffer.getvalue()).decode()
                buffer.close()
                plt.close()

        except Exception as e:
            pasos.append(f"Error: {e}")

    return render(request, 'calculadora/richardson.html', {
        'resultado': resultado,
        'pasos': pasos,
        'nombre': nombre,
        'mostrar_pasos': mostrar_pasos,
        'grafico': grafico,
        'rehacer_datos': rehacer_datos,
    })

def ver_historial(request, id):
    registro = get_object_or_404(Historial, id=id, usuario=request.user)
    return render(request, 'calculadora/ver_historial.html', {'registro': registro})

def rehacer_view(request, historial_id):
    historial = get_object_or_404(Historial, id=historial_id, usuario=request.user)
    if historial.metodo == "Lagrange":
        return redirect(f"{reverse('calculadora:lagrange')}?rehacer={historial.id}")
    elif historial.metodo == "Richardson":
        return redirect(f"{reverse('calculadora:richardson')}?rehacer={historial.id}")
    return redirect("calculadora:historial")

def documentacion_view(request):
    return render(request, 'calculadora/documentacion.html')

def creditos_view(request):
    return render(request, 'calculadora/creditos.html')
